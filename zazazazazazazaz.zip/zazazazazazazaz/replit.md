# LUCREI - Sistema de Gestão Financeira SaaS

## Overview
LUCREI is a comprehensive SaaS financial management system designed for small and medium-sized businesses. It offers robust management of organizations, clients, invoices, financial transactions, categories, cost centers, documents, tags, OFX imports, exports, and detailed reports. The project aims to provide a modern, responsive, and fully functional platform that centralizes financial operations and enhances business efficiency with a standardized, intuitive user experience.

## User Preferences
- I prefer simple language and clear explanations.
- I want iterative development with frequent updates and feedback loops.
- Ask before making major changes to the core architecture or existing functionalities.
- Ensure all new features align with the established design system and visual patterns.
- Prioritize security and data integrity in all implementations.
- Do not make changes to the file `design_guidelines.md`.

## Recent Changes (November 2025)
### Backend Improvements
- ✅ **Session Store:** Migrated from MemoryStore to PostgreSQL using `connect-pg-simple` for persistent sessions
- ✅ **Session Secret:** Removed fallback, now requires `SESSION_SECRET` environment variable
- ✅ **Complete CRUD APIs:** Implemented full CRUD operations for all entities:
  - Transactions (income/expense tracking with categories, tags, accounts)
  - Categories (hierarchical with income/expense types)
  - Bank Accounts (with balance tracking)
  - Cost Centers (for expense allocation)
  - Tags (many-to-many with transactions)
  - Documents (file management with entity linking)
  - Reconciliations (OFX file processing)
  - User Preferences (theme, language, notifications, etc)
- ✅ **Financial Reports:** Real calculations for DRE, Cash Flow, and Statement reports
- ✅ **Data Export:** Excel, CSV, and JSON exports for transactions, customers, and invoices
- ✅ **User Management:** Profile updates, password changes, preferences management

### Database Schema
- ✅ Extended database with new tables: categories, bank_accounts, cost_centers, tags, transactions, transaction_tags, documents, reconciliations, user_preferences
- ✅ All tables include proper relationships and foreign keys
- ✅ Using Drizzle ORM for type-safe database operations

### Security Enhancements
- ✅ PostgreSQL session store (persistent sessions across server restarts)
- ✅ Mandatory SESSION_SECRET (no fallback to insecure default)
- ✅ Rate limiting on all API routes
- ✅ Helmet for HTTP security headers
- ✅ CORS properly configured

## System Architecture
LUCREI is built with a client-server architecture using **React 18** (Vite) for the frontend and **Express.js** (Node.js 20) for the backend. **TypeScript** is used across the entire stack for type safety.

### UI/UX Decisions
The system follows a modern, standardized design with a focus on responsiveness and user-friendliness.
- **Consistent Design System:** All pages adhere to a modern visual standard using `shadcn/ui` components.
- **Theming:** Supports dark/light themes with `next-themes`.
- **Animations:** Smooth transitions and micro-interactions are implemented using `Framer Motion`.
- **Visuals:** Features gradients in titles (`bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent`), colored cards with shadows, gradient-backed Lucide React icons, and colored badges for status indicators.
- **Data Visualization:** Interactive charts and graphs are powered by `Recharts`.

### Technical Implementations
- **Backend:**
    - **Database:** PostgreSQL with `Drizzle ORM` for schema management and data access. **Session storage** using PostgreSQL via `connect-pg-simple`.
    - **API:** Full RESTful API supporting CRUD operations for all entities (Organizations, Users, Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, Subscriptions). Includes dedicated endpoints for metrics, activity logs, financial reports (DRE, Cash Flow, Statement), and data exports.
    - **Authentication:** Session-based authentication using `Passport.js` and `express-session` with PostgreSQL store, password hashing via `bcryptjs` (10 rounds).
    - **Authorization:** Role-based access control (OWNER, ADMIN, CUSTOMER) and organization-level data isolation.
    - **Validation:** Server-side data validation using `Zod` schemas for all entities.
    - **Security:** `Helmet` for HTTP headers, CORS configured, `express-rate-limit` for rate limiting, mandatory `SESSION_SECRET` environment variable.
    - **Exports:** XLSX and CSV generation using `xlsx` and `json2csv` libraries.
- **Frontend:**
    - **State Management & Data Fetching:** `TanStack Query (React Query)` handles data fetching, caching, and synchronization.
    - **Routing:** Light-weight client-side routing with `Wouter`.
    - **Form Management:** `React Hook Form` integrated with `Zod` for client-side validation.

### Feature Specifications
- **Core Modules:** Management for Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, and Subscriptions.
- **Dashboard:** Centralized view with key metrics, interactive charts, recent activities, and invoice statistics.
- **Financial Transactions:** Complete transaction management with support for income/expense categorization, bank account linking, cost center allocation, tags, and document attachments.
- **Reporting:** Real-time financial reports with actual calculations:
  - **DRE (Demonstração de Resultados do Exercício):** Income statement with revenue/expense breakdown by category
  - **Cash Flow:** Monthly cash flow analysis with running balance
  - **Statement:** Detailed transaction listing with filters and totals
- **Data Operations:** 
  - **Exports:** Excel, CSV, and JSON exports for transactions, customers, and invoices
  - **OFX:** Reconciliation framework (basic CRUD implemented)
- **Settings:** 
  - **User Profile:** Update name, email, avatar, and password
  - **Preferences:** Theme, language, notifications, currency, date format
  - **Organization:** Manage organization details

### System Design Choices
- **Modularity:** Project structure separates client, server, and shared code (`lucrei/client`, `lucrei/server`, `lucrei/shared`).
- **Scalability:** Designed with considerations for future scalability, including potential for queue systems, distributed caching, and CDN integration.
- **Observability:** Focus on logging and monitoring in production environments.
- **Deployment:** Configured for automated deployment on Replit and compatible with manual production deployments.

## External Dependencies
- **Stripe:** For payment processing and subscription management (integration pending).
- **PostgreSQL:** Primary database, utilized with `@neondatabase/serverless` for serverless environments.
- **connect-pg-simple:** PostgreSQL session store for `express-session`.
- **Passport.js:** Authentication middleware.
- **bcryptjs:** Password hashing library.
- **Zod:** Schema declaration and validation library (used both frontend and backend).
- **xlsx:** Excel file generation for exports.
- **json2csv:** CSV file generation for exports.
- **Recharts:** Charting library for data visualization.
- **Lucide React:** Icon library.
- **Framer Motion:** Animation library.
- **TanStack Query (React Query):** Data fetching and caching library.
- **shadcn/ui:** UI component library.
- **Tailwind CSS:** Utility-first CSS framework.
- **Vite:** Frontend build tool with HMR configured for Replit.
- **Node.js 20:** JavaScript runtime environment.

## Pending Implementations
- **Stripe Integration:** Webhooks and subscription management (basic schema exists)
- **OFX Parser:** Complete OFX file parsing and automatic reconciliation
- **PDF Exports:** PDF generation for reports and invoices
- **File Upload:** Document upload system with storage
- **Pagination:** Implement pagination on all list endpoints
- **Frontend Loading States:** Add loading skeletons and error boundaries
- **CSRF Protection:** Add CSRF tokens for form submissions