import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Download, TrendingUp, TrendingDown, DollarSign, BarChart3, PieChart as PieChartIcon, FileSpreadsheet, Calendar, Filter } from "lucide-react";
import { motion } from "framer-motion";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
  Area,
  AreaChart,
} from "recharts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const COLORS = ['#10b981', '#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899'];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function ReportsPage() {
  const [startDate, setStartDate] = useState("2025-11-01");
  const [endDate, setEndDate] = useState("2025-11-30");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [includesPaid, setIncludesPaid] = useState(true);
  const [includesUnpaid, setIncludesUnpaid] = useState(true);

  const cashFlowData = [
    { month: "Jan", receitas: 4500, despesas: 3200, lucro: 1300 },
    { month: "Fev", receitas: 6200, despesas: 4100, lucro: 2100 },
    { month: "Mar", receitas: 5800, despesas: 3800, lucro: 2000 },
    { month: "Abr", receitas: 7200, despesas: 4500, lucro: 2700 },
    { month: "Mai", receitas: 8400, despesas: 5200, lucro: 3200 },
    { month: "Jun", receitas: 9500, despesas: 5800, lucro: 3700 },
  ];

  const categoryData = [
    { name: "Vendas", value: 45, amount: 45000 },
    { name: "Serviços", value: 30, amount: 30000 },
    { name: "Operacional", value: 15, amount: 15000 },
    { name: "Fixas", value: 10, amount: 10000 },
  ];

  const dreData = {
    receitaBruta: 85000,
    deducoes: 8500,
    receitaLiquida: 76500,
    custos: 35000,
    lucro: 41500,
    despesasOperacionais: 15000,
    lucroOperacional: 26500,
    impostos: 5300,
    lucroLiquido: 21200,
  };

  const extractData = [
    { date: "08/11/2025", description: "Venda Produto #1234", type: "Receita", category: "Vendas", value: 2850 },
    { date: "07/11/2025", description: "Pagamento Fornecedor", type: "Despesa", category: "Operacional", value: -1680 },
    { date: "06/11/2025", description: "Serviço Consultoria", type: "Receita", category: "Serviços", value: 3850 },
    { date: "05/11/2025", description: "Aluguel Escritório", type: "Despesa", category: "Fixas", value: -2500 },
  ];

  const revenueExpenseData = [
    { category: "Vendas", receitas: 45000, despesas: 0, saldo: 45000 },
    { category: "Serviços", receitas: 30000, despesas: 0, saldo: 30000 },
    { category: "Operacional", receitas: 0, despesas: 15000, saldo: -15000 },
    { category: "Fixas", receitas: 0, despesas: 10000, saldo: -10000 },
    { category: "Marketing", receitas: 0, despesas: 5000, saldo: -5000 },
  ];

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">Relatórios</h1>
            <p className="text-muted-foreground mt-1">
              Análise completa e insights financeiros
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2">
              <Calendar className="h-4 w-4" />
              Agendar Relatório
            </Button>
            <Button className="gap-2 shadow-lg shadow-primary/20">
              <Download className="h-4 w-4" />
              Exportar Tudo
            </Button>
          </div>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filtros de Relatório
              </CardTitle>
              <CardDescription>Configure os parâmetros para gerar relatórios personalizados</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Data inicial</Label>
                  <Input 
                    id="startDate"
                    type="date" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate">Data final</Label>
                  <Input 
                    id="endDate"
                    type="date" 
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Categorias</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger id="category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      <SelectItem value="income">Receitas</SelectItem>
                      <SelectItem value="expenses">Despesas</SelectItem>
                      <SelectItem value="sales">Vendas</SelectItem>
                      <SelectItem value="services">Serviços</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="account">Contas</Label>
                  <Select defaultValue="all">
                    <SelectTrigger id="account">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas as contas</SelectItem>
                      <SelectItem value="main">Conta Principal</SelectItem>
                      <SelectItem value="business">Conta Empresarial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-3 border-t pt-4">
                <Label>Incluir lançamentos</Label>
                <div className="flex flex-wrap gap-6">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="paid" 
                      checked={includesPaid}
                      onCheckedChange={(checked) => setIncludesPaid(checked as boolean)}
                    />
                    <label htmlFor="paid" className="text-sm font-medium cursor-pointer">
                      Pagos
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="unpaid" 
                      checked={includesUnpaid}
                      onCheckedChange={(checked) => setIncludesUnpaid(checked as boolean)}
                    />
                    <label htmlFor="unpaid" className="text-sm font-medium cursor-pointer">
                      Não pagos
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="overdue" />
                    <label htmlFor="overdue" className="text-sm font-medium cursor-pointer">
                      Vencidos
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="future" />
                    <label htmlFor="future" className="text-sm font-medium cursor-pointer">
                      Futuros
                    </label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Tabs defaultValue="cashflow" className="w-full">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
              <TabsTrigger value="cashflow" className="gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Fluxo de Caixa</span>
                <span className="sm:hidden">Fluxo</span>
              </TabsTrigger>
              <TabsTrigger value="dre" className="gap-2">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">DRE</span>
                <span className="sm:hidden">DRE</span>
              </TabsTrigger>
              <TabsTrigger value="extract" className="gap-2">
                <FileSpreadsheet className="h-4 w-4" />
                <span className="hidden sm:inline">Extrato</span>
                <span className="sm:hidden">Extrato</span>
              </TabsTrigger>
              <TabsTrigger value="income" className="gap-2">
                <PieChartIcon className="h-4 w-4" />
                <span className="hidden sm:inline">Receitas/Despesas</span>
                <span className="sm:hidden">Rec/Desp</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="cashflow" className="mt-6 space-y-6">
              <div className="grid gap-6 md:grid-cols-3">
                <Card className="border-l-4 border-l-green-500">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Total Receitas</p>
                        <p className="text-2xl font-bold text-green-600 mt-2">
                          R$ 41.600,00
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-red-500">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Total Despesas</p>
                        <p className="text-2xl font-bold text-red-600 mt-2">
                          R$ 26.600,00
                        </p>
                      </div>
                      <TrendingDown className="h-8 w-8 text-red-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-blue-500">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Saldo do Período</p>
                        <p className="text-2xl font-bold text-blue-600 mt-2">
                          R$ 15.000,00
                        </p>
                      </div>
                      <DollarSign className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Evolução Mensal</CardTitle>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <AreaChart data={cashFlowData}>
                      <defs>
                        <linearGradient id="colorReceitas" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorDespesas" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorLucro" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="receitas" stroke="#10b981" fillOpacity={1} fill="url(#colorReceitas)" />
                      <Area type="monotone" dataKey="despesas" stroke="#ef4444" fillOpacity={1} fill="url(#colorDespesas)" />
                      <Area type="monotone" dataKey="lucro" stroke="#3b82f6" fillOpacity={1} fill="url(#colorLucro)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="dre" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Demonstração do Resultado do Exercício (DRE)</CardTitle>
                      <CardDescription className="mt-1">Análise detalhada de receitas, custos e lucros</CardDescription>
                    </div>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar PDF
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                      <span className="font-semibold">Receita Bruta</span>
                      <span className="text-xl font-bold text-green-600">
                        R$ {dreData.receitaBruta.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
                      <span className="font-semibold">(-) Deduções e Abatimentos</span>
                      <span className="text-xl font-bold text-red-600">
                        R$ {dreData.deducoes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border-2 border-blue-200 dark:border-blue-800">
                      <span className="font-bold">= Receita Líquida</span>
                      <span className="text-xl font-bold text-blue-600">
                        R$ {dreData.receitaLiquida.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
                      <span className="font-semibold">(-) Custos</span>
                      <span className="text-xl font-bold text-red-600">
                        R$ {dreData.custos.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border-2 border-green-200 dark:border-green-800">
                      <span className="font-bold">= Lucro Bruto</span>
                      <span className="text-xl font-bold text-green-600">
                        R$ {dreData.lucro.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
                      <span className="font-semibold">(-) Despesas Operacionais</span>
                      <span className="text-xl font-bold text-red-600">
                        R$ {dreData.despesasOperacionais.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border-2 border-green-200 dark:border-green-800">
                      <span className="font-bold">= Lucro Operacional</span>
                      <span className="text-xl font-bold text-green-600">
                        R$ {dreData.lucroOperacional.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
                      <span className="font-semibold">(-) Impostos</span>
                      <span className="text-xl font-bold text-red-600">
                        R$ {dreData.impostos.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-6 bg-gradient-to-r from-primary/20 to-primary/10 rounded-lg border-2 border-primary">
                      <span className="text-lg font-bold">= LUCRO LÍQUIDO</span>
                      <span className="text-2xl font-bold text-primary">
                        R$ {dreData.lucroLiquido.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="extract" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Extrato Detalhado</CardTitle>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar Excel
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Descrição</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead className="text-right">Valor</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {extractData.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{item.date}</TableCell>
                          <TableCell>{item.description}</TableCell>
                          <TableCell>
                            <Badge variant={item.type === "Receita" ? "default" : "secondary"}>
                              {item.type}
                            </Badge>
                          </TableCell>
                          <TableCell>{item.category}</TableCell>
                          <TableCell className="text-right">
                            <span className={`font-semibold ${item.value > 0 ? "text-green-600" : "text-red-600"}`}>
                              {item.value > 0 ? "+" : ""} R$ {Math.abs(item.value).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="income" className="mt-6 space-y-6">
              <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Distribuição por Categoria</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name}: ${value}%`}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Receitas vs Despesas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={revenueExpenseData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="category" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="receitas" fill="#10b981" />
                        <Bar dataKey="despesas" fill="#ef4444" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Análise Detalhada por Categoria</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Categoria</TableHead>
                        <TableHead className="text-right">Receitas</TableHead>
                        <TableHead className="text-right">Despesas</TableHead>
                        <TableHead className="text-right">Saldo</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {revenueExpenseData.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{item.category}</TableCell>
                          <TableCell className="text-right text-green-600 font-semibold">
                            R$ {item.receitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </TableCell>
                          <TableCell className="text-right text-red-600 font-semibold">
                            R$ {item.despesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </TableCell>
                          <TableCell className="text-right">
                            <span className={`font-bold ${item.saldo >= 0 ? "text-green-600" : "text-red-600"}`}>
                              R$ {item.saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
