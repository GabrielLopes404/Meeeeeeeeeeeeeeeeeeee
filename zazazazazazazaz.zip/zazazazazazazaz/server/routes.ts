import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";
import { db } from "./db";
import { storage } from "./storage";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcryptjs";
import XLSX from "xlsx";
import { Parser } from "json2csv";
import {
  insertUserSchema,
  insertOrganizationSchema,
  createCustomerSchema,
  createInvoiceSchema,
  createCategorySchema,
  createBankAccountSchema,
  createCostCenterSchema,
  createTagSchema,
  createTransactionSchema,
  createDocumentSchema,
  createReconciliationSchema,
  type User,
} from "@shared/schema";

// Extend Express session to include user
declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      email: string;
      organizationId: string | null;
      role: "OWNER" | "ADMIN" | "CUSTOMER";
    }
  }
}

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user is admin or owner
function isAdminOrOwner(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && (req.user!.role === "ADMIN" || req.user!.role === "OWNER")) {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin or Owner access required" });
}

// Validation middleware
function validateBody(schema: z.ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        res.status(400).json({ message: "Invalid request body" });
      }
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Vite handles CSP in dev
  }));
  
  // CORS configuration
  app.use(cors({
    origin: process.env.NODE_ENV === "production" 
      ? process.env.ALLOWED_ORIGINS?.split(',') || []
      : true,
    credentials: true,
  }));

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: "Muitas requisições, tente novamente em breve.",
    standardHeaders: true,
    legacyHeaders: false,
  });

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 login attempts
    message: "Muitas tentativas de login, tente novamente em 15 minutos.",
    skipSuccessfulRequests: true,
  });

  app.use("/api/", limiter);

  // Session configuration with PostgreSQL store
  const PgSession = connectPgSimple(session);
  
  if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET environment variable is required");
  }

  app.use(
    session({
      store: new PgSession({
        conObject: {
          connectionString: process.env.DATABASE_URL,
        },
        tableName: 'session',
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
        sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
      },
    })
  );

  // Passport configuration
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            return done(null, false, { message: "Invalid credentials" });
          }

          const isValid = await bcrypt.compare(password, user.password);
          if (!isValid) {
            return done(null, false, { message: "Invalid credentials" });
          }

          return done(null, {
            id: user.id,
            username: user.username,
            email: user.email,
            organizationId: user.organizationId,
            role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
          });
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      done(null, {
        id: user.id,
        username: user.username,
        email: user.email,
        organizationId: user.organizationId,
        role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
      });
    } catch (error) {
      done(error);
    }
  });

  // AUTH ROUTES
  // Register
  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response) => {
    try {
      const { email, password, username, name, organizationName } = req.body;

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create organization first
      const organization = await storage.createOrganization({
        name: organizationName || `${name}'s Organization`,
        email,
      });

      // Create user
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name,
        organizationId: organization.id,
        role: "OWNER",
        emailVerified: false,
      });

      // Log activity
      await storage.createActivity({
        organizationId: organization.id,
        userId: user.id,
        action: "user_registered",
        entityType: "user",
        entityId: user.id,
        details: JSON.stringify({ email }),
      });

      // Auto login after registration
      req.login(
        {
          id: user.id,
          username: user.username,
          email: user.email,
          organizationId: user.organizationId,
          role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
        },
        (err) => {
          if (err) {
            return res.status(500).json({ message: "Registration successful but login failed" });
          }
          res.json({
            user: {
              id: user.id,
              username: user.username,
              email: user.email,
              name: user.name,
              organizationId: user.organizationId,
              role: user.role,
            },
          });
        }
      );
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Login
  app.post("/api/auth/login", authLimiter, (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Login failed" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Login failed" });
        }
        res.json({ user });
      });
    })(req, res, next);
  });

  // Logout
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", isAuthenticated, (req: Request, res: Response) => {
    res.json({ user: req.user });
  });

  // ORGANIZATIONS ROUTES
  // Get current organization
  app.get("/api/organizations/current", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(404).json({ message: "No organization found" });
      }
      const organization = await storage.getOrganization(req.user!.organizationId);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch organization" });
    }
  });

  // Update organization
  app.put("/api/organizations/:id", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      if (id !== req.user!.organizationId) {
        return res.status(403).json({ message: "Cannot update other organizations" });
      }
      const organization = await storage.updateOrganization(id, req.body);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to update organization" });
    }
  });

  // CUSTOMERS ROUTES
  // Get all customers for organization
  app.get("/api/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const customers = await storage.getCustomersByOrganization(req.user!.organizationId);
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  // Get single customer
  app.get("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  // Create customer
  app.post(
    "/api/customers",
    isAuthenticated,
    validateBody(createCustomerSchema),
    async (req: Request, res: Response) => {
      try {
        const customer = await storage.createCustomer({
          ...req.body,
          organizationId: req.user!.organizationId!,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "customer_created",
          entityType: "customer",
          entityId: customer.id,
          details: JSON.stringify({ name: customer.name }),
        });

        res.status(201).json(customer);
      } catch (error) {
        res.status(500).json({ message: "Failed to create customer" });
      }
    }
  );

  // Update customer
  app.put("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const customer = await storage.updateCustomer(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_updated",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: customer?.name }),
      });

      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  // Delete customer
  app.delete("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      await storage.deleteCustomer(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_deleted",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: existing.name }),
      });

      res.json({ message: "Customer deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // INVOICES ROUTES
  // Get all invoices for organization
  app.get("/api/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const invoices = await storage.getInvoicesByOrganization(req.user!.organizationId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get invoices by customer
  app.get("/api/customers/:customerId/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.customerId);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const invoices = await storage.getInvoicesByCustomer(req.params.customerId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get single invoice
  app.get("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  // Create invoice
  app.post(
    "/api/invoices",
    isAuthenticated,
    validateBody(createInvoiceSchema),
    async (req: Request, res: Response) => {
      try {
        // Verify customer belongs to organization
        const customer = await storage.getCustomer(req.body.customerId);
        if (!customer || customer.organizationId !== req.user!.organizationId) {
          return res.status(400).json({ message: "Invalid customer" });
        }

        // Generate invoice number
        const timestamp = Date.now();
        const invoiceNumber = `INV-${timestamp}`;

        const invoice = await storage.createInvoice({
          ...req.body,
          organizationId: req.user!.organizationId!,
          invoiceNumber,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "invoice_created",
          entityType: "invoice",
          entityId: invoice.id,
          details: JSON.stringify({ invoiceNumber, amount: invoice.amount }),
        });

        res.status(201).json(invoice);
      } catch (error) {
        res.status(500).json({ message: "Failed to create invoice" });
      }
    }
  );

  // Update invoice
  app.put("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const invoice = await storage.updateInvoice(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_updated",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: invoice?.invoiceNumber }),
      });

      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to update invoice" });
    }
  });

  // Delete invoice
  app.delete("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      await storage.deleteInvoice(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_deleted",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: existing.invoiceNumber }),
      });

      res.json({ message: "Invoice deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete invoice" });
    }
  });

  // METRICS ROUTES
  app.get("/api/metrics", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const metrics = await storage.getMetrics(req.user!.organizationId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Monthly Revenue Data
  app.get("/api/metrics/monthly-revenue", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const data = await storage.getMonthlyRevenueData(req.user!.organizationId);
      res.json(data);
    } catch (error) {
      console.error("Failed to fetch monthly revenue:", error);
      res.status(500).json({ message: "Failed to fetch monthly revenue data" });
    }
  });

  // ACTIVITIES ROUTES
  app.get("/api/activities", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const activities = await storage.getActivitiesByOrganization(req.user!.organizationId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // CATEGORIES ROUTES
  app.get("/api/categories", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const categories = await storage.getCategoriesByOrganization(req.user!.organizationId);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", isAuthenticated, validateBody(createCategorySchema), async (req: Request, res: Response) => {
    try {
      const category = await storage.createCategory({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put("/api/categories/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCategory(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Category not found" });
      }
      const category = await storage.updateCategory(req.params.id, req.body);
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCategory(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Category not found" });
      }
      await storage.deleteCategory(req.params.id);
      res.json({ message: "Category deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // BANK ACCOUNTS ROUTES
  app.get("/api/bank-accounts", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const accounts = await storage.getBankAccountsByOrganization(req.user!.organizationId);
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bank accounts" });
    }
  });

  app.post("/api/bank-accounts", isAuthenticated, validateBody(createBankAccountSchema), async (req: Request, res: Response) => {
    try {
      const account = await storage.createBankAccount({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to create bank account" });
    }
  });

  app.put("/api/bank-accounts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getBankAccount(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      const account = await storage.updateBankAccount(req.params.id, req.body);
      res.json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to update bank account" });
    }
  });

  app.delete("/api/bank-accounts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getBankAccount(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      await storage.deleteBankAccount(req.params.id);
      res.json({ message: "Bank account deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete bank account" });
    }
  });

  // COST CENTERS ROUTES
  app.get("/api/cost-centers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const centers = await storage.getCostCentersByOrganization(req.user!.organizationId);
      res.json(centers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cost centers" });
    }
  });

  app.post("/api/cost-centers", isAuthenticated, validateBody(createCostCenterSchema), async (req: Request, res: Response) => {
    try {
      const center = await storage.createCostCenter({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(center);
    } catch (error) {
      res.status(500).json({ message: "Failed to create cost center" });
    }
  });

  app.put("/api/cost-centers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCostCenter(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Cost center not found" });
      }
      const center = await storage.updateCostCenter(req.params.id, req.body);
      res.json(center);
    } catch (error) {
      res.status(500).json({ message: "Failed to update cost center" });
    }
  });

  app.delete("/api/cost-centers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCostCenter(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Cost center not found" });
      }
      await storage.deleteCostCenter(req.params.id);
      res.json({ message: "Cost center deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete cost center" });
    }
  });

  // TAGS ROUTES
  app.get("/api/tags", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const tags = await storage.getTagsByOrganization(req.user!.organizationId);
      res.json(tags);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tags" });
    }
  });

  app.post("/api/tags", isAuthenticated, validateBody(createTagSchema), async (req: Request, res: Response) => {
    try {
      const tag = await storage.createTag({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(tag);
    } catch (error) {
      res.status(500).json({ message: "Failed to create tag" });
    }
  });

  app.put("/api/tags/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTag(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Tag not found" });
      }
      const tag = await storage.updateTag(req.params.id, req.body);
      res.json(tag);
    } catch (error) {
      res.status(500).json({ message: "Failed to update tag" });
    }
  });

  app.delete("/api/tags/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTag(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Tag not found" });
      }
      await storage.deleteTag(req.params.id);
      res.json({ message: "Tag deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete tag" });
    }
  });

  // TRANSACTIONS ROUTES
  app.get("/api/transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transactions = await storage.getTransactionsByOrganization(req.user!.organizationId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const transaction = await storage.getTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transaction" });
    }
  });

  app.post("/api/transactions", isAuthenticated, validateBody(createTransactionSchema), async (req: Request, res: Response) => {
    try {
      const transaction = await storage.createTransaction({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "transaction_created",
        entityType: "transaction",
        entityId: transaction.id,
        details: JSON.stringify({ description: transaction.description, amount: transaction.amount }),
      });

      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  app.put("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      const transaction = await storage.updateTransaction(req.params.id, req.body);
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update transaction" });
    }
  });

  app.delete("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      await storage.deleteTransaction(req.params.id);
      res.json({ message: "Transaction deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // DOCUMENTS ROUTES
  app.get("/api/documents", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const documents = await storage.getDocumentsByOrganization(req.user!.organizationId);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/documents", isAuthenticated, validateBody(createDocumentSchema), async (req: Request, res: Response) => {
    try {
      const document = await storage.createDocument({
        ...req.body,
        organizationId: req.user!.organizationId!,
        uploadedBy: req.user!.id,
      });
      res.status(201).json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  app.delete("/api/documents/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getDocument(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Document not found" });
      }
      await storage.deleteDocument(req.params.id);
      res.json({ message: "Document deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  // RECONCILIATIONS ROUTES
  app.get("/api/reconciliations", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const reconciliations = await storage.getReconciliationsByOrganization(req.user!.organizationId);
      res.json(reconciliations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reconciliations" });
    }
  });

  app.post("/api/reconciliations", isAuthenticated, validateBody(createReconciliationSchema), async (req: Request, res: Response) => {
    try {
      const reconciliation = await storage.createReconciliation({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(reconciliation);
    } catch (error) {
      res.status(500).json({ message: "Failed to create reconciliation" });
    }
  });

  app.delete("/api/reconciliations/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getReconciliation(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Reconciliation not found" });
      }
      await storage.deleteReconciliation(req.params.id);
      res.json({ message: "Reconciliation deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete reconciliation" });
    }
  });

  // USER PREFERENCES ROUTES
  app.get("/api/user/preferences", isAuthenticated, async (req: Request, res: Response) => {
    try {
      let preferences = await storage.getUserPreferences(req.user!.id);
      if (!preferences) {
        preferences = await storage.createUserPreferences({
          userId: req.user!.id,
        });
      }
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.put("/api/user/preferences", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const preferences = await storage.updateUserPreferences(req.user!.id, req.body);
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // USER PROFILE ROUTES
  app.put("/api/user/profile", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { name, email, avatar } = req.body;
      const user = await storage.updateUser(req.user!.id, { name, email, avatar });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put("/api/user/password", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !await bcrypt.compare(currentPassword, user.password)) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(req.user!.id, { password: hashedPassword });
      
      res.json({ message: "Password updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update password" });
    }
  });

  // REPORTS ROUTES
  app.get("/api/reports/dre", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getDREReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate DRE report:", error);
      res.status(500).json({ message: "Failed to generate DRE report" });
    }
  });

  app.get("/api/reports/cash-flow", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getCashFlowReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate cash flow report:", error);
      res.status(500).json({ message: "Failed to generate cash flow report" });
    }
  });

  app.get("/api/reports/statement", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getStatementReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate statement report:", error);
      res.status(500).json({ message: "Failed to generate statement report" });
    }
  });

  // EXPORT ROUTES
  app.get("/api/export/transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const transactions = await storage.getTransactionsByOrganization(req.user!.organizationId);
      
      const data = transactions.map(t => ({
        Data: t.date,
        Descrição: t.description,
        Tipo: t.type === 'income' ? 'Receita' : 'Despesa',
        Valor: parseFloat(t.amount),
        Pago: t.isPaid ? 'Sim' : 'Não',
        'Data Pagamento': t.paidDate || '',
        Observações: t.notes || ''
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Transações");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=transacoes_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=transacoes_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export transactions:", error);
      res.status(500).json({ message: "Failed to export transactions" });
    }
  });

  app.get("/api/export/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const customers = await storage.getCustomersByOrganization(req.user!.organizationId);
      
      const data = customers.map(c => ({
        Nome: c.name,
        Email: c.email,
        Telefone: c.phone || '',
        Documento: c.document || '',
        Cidade: c.city || '',
        Estado: c.state || '',
        'Data Criação': c.createdAt
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Clientes");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=clientes_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=clientes_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export customers:", error);
      res.status(500).json({ message: "Failed to export customers" });
    }
  });

  app.get("/api/export/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const invoices = await storage.getInvoicesByOrganization(req.user!.organizationId);
      
      const data = invoices.map(i => ({
        'Número': i.invoiceNumber,
        Descrição: i.description || '',
        Valor: parseFloat(i.amount),
        Status: i.status,
        'Data Emissão': i.issueDate,
        Vencimento: i.dueDate || '',
        'Data Pagamento': i.paidDate || ''
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Faturas");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=faturas_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=faturas_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export invoices:", error);
      res.status(500).json({ message: "Failed to export invoices" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
